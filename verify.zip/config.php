<?php
define('API_KEY', 'tO7FhdtPBXy7UyCvrL0q4eq8xFC7qhmd');

define('SMTP_HOST', 'smtp.hostinger.com');
define('SMTP_PORT', 465);
define('SMTP_USER', 'verify@findthefirm.com');
define('SMTP_PASS', 'Speed@#$135');
define('SENDER_EMAIL', 'verify@findthefirm.com');

define('ADMIN_USER', 'admin');
define('ADMIN_PASS', 'verify2025');
define('ADMIN_EMAIL', 'verify@findthefirm.com');

define('DB_PATH', __DIR__ . '/db.sqlite');
define('LOG_PATH', __DIR__ . '/logs/webhook.log');

session_start();
?>